const express = require("express");
const Category = require("./app/controllers/Category");
const List = require("./app/controllers/List")

const routes = express.Router();

routes.get('/category', Category.indexCategory)
routes.post("/category", Category.createCategory)
routes.delete("/category/:id", Category.deleteCategory)
routes.put("/category/:id", Category.updateCategory)

routes.get('/list', List.indexList);
routes.get('/list/:id', List.indexListId);
routes.post('/list', List.createList);
routes.put('/list/:id', List.updateList);
routes.delete('/list/:id', List.deleteList);

module.exports = routes;