const db = require("../models/ConnectDatabase");

const indexCategory = async (req, res) => {
  try {
    const result = await db.query(`SELECT * FROM category ORDER BY id;`);
    return res.status(200).json(result);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erro ao listar as categorias" });
  }
};

const createCategory = async (req, res) => {
  const { name } = req.body;
  if (!name) {
    return res.status(400).json({ message: "Nome é obrigatório" });
  }
  try {
    await db.query(`INSERT INTO category (name) VALUES (?);`, [name]);
    return res.status(201).json({ message: "Categoria criada com sucesso!" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erro ao criar categoria" });
  }
};

const updateCategory = async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: "Nome é obrigatório" });
  }

  try {
    const result = await db.query(`UPDATE category SET name = ? WHERE id = ?;`, [name, id]);
    if (result.affectedRows === 0) {
      return res.status(400).json({ message: "Categoria não encontrada" });
    }
    return res.status(200).json({ message: "Categoria atualizada com sucesso!" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erro ao atualizar categoria" });
  }
};

const deleteCategory = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await db.query(`DELETE FROM category WHERE id = ?;`, [id]);
    if (result.affectedRows === 0) {
      return res.status(400).json({ message: "Categoria não encontrada" });
    }
    return res.status(200).json({ message: "Categoria deletada com sucesso!" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erro ao deletar categoria" });
  }
};

module.exports = {
  indexCategory,
  createCategory,
  updateCategory,
  deleteCategory,
};
