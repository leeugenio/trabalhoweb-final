const db = require("../models/ConnectDatabase");

const indexList = async (req, res) => {
    try {
        const result = await db.query(`
            SELECT list.id, list.name, list.date, list.time, list.description, category.name AS category_name
            FROM list
            JOIN category ON list.category_id = category.id;
        `);
        return res.status(200).json(result);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Erro ao listar as tarefas" });
    }
};

const indexListId = async (req, res) => {
    const { id } = req.params;
    try {
        const result = await db.query(`
        SELECT list.id, list.name, list.date, list.time, list.description, category.name AS category_name
        FROM list
        JOIN category ON list.category_id = category.id 
        WHERE list.id = ?;
    `, [id]);
        if (result.length === 0) {
            return res.status(400).json({ message: "Tarefa não encontrada" });
        }
        return res.status(200).json(result);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Erro ao listar a tarefa" });
    }
};

const createList = async (req, res) => {
    const { name, date, time, description, category_id } = req.body;

    if (!name || !date || !time) {
        return res.status(400).json({ message: "Título, data e hora são obrigatórios." });
    }

    try {
        await db.query(
            `INSERT INTO list (name, date, time, description, category_id) VALUES (?, ?, ?, ?, ?);`,
            [name, date, time, description, category_id]
        );
        return res.status(201).json({ message: "Tarefa criada com sucesso!" });
    } catch (error) {
        console.error("Erro ao criar tarefa:", error);
        return res.status(500).json({ message: "Erro ao criar tarefa." });
    }
};


const updateList = async (req, res) => {
    const { id } = req.params;
    const { name, description, category_id } = req.body;

    let query = "UPDATE list SET ";
    let values = [];

    if (name) {
        query += "name = ?, ";
        values.push(name);
    }

    if (description) {
        query += "description = ?, ";
        values.push(description);
    }


    if (category_id) {
        query += "category_id = ?, ";
        values.push(category_id);
    }


    if (values.length === 0) {
        return res.status(400).json({ message: "Nenhum campo para atualizar fornecido." });
    }


    query = query.slice(0, -2);

    query += " WHERE id = ?";

    values.push(id);

    try {

        const result = await db.query(query, values);

        if (result.affectedRows === 0) {
            return res.status(400).json({ message: "Tarefa não encontrada" });
        }

        return res.status(200).json({ message: "Tarefa atualizada com sucesso!" });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Erro ao atualizar tarefa" });
    }
};

const deleteList = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await db.query(`DELETE FROM list WHERE id = ?;`, [id]);
        if (result.rowCount === 0) {
            return res.status(400).json({ message: "Tarefa não encontrada" });
        }
        return res.status(200).json({ message: "Tarefa deletada com sucesso!" });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Erro ao deletar tarefa" });
    }
};

module.exports = {
    indexList,
    indexListId,
    createList,
    updateList,
    deleteList
};
