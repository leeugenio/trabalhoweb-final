DROP DATABASE IF EXISTS todolist;

CREATE DATABASE todolist;

\c todolist;

CREATE TABLE IF NOT EXISTS category (
    id SERIAL PRIMARY KEY, 
    name VARCHAR(255) NOT NULL
);

INSERT INTO category (name)
VALUES 
('Casa'),
('Faculdade'),
('Trabalho'),
('Outro');


CREATE TABLE IF NOT EXISTS list (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    description VARCHAR(500),
    date DATE NOT NULL,
    time TIME NOT NULL,
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES category(id)
);


\dt;
