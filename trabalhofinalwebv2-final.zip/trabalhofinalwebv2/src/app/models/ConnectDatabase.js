const { Pool } = require("pg");

const client = new Pool({
  host: "localhost",
  port: 5432, 
  user: "postgres", 
  password: "leon", 
  database: "todolist", 
});

const testConnection = async () => {
  try {
    const connection = await client.connect();
    console.log("PostgreSQL conectado com sucesso!");
    connection.release();
  } catch (error) {
    console.error("Erro ao conectar ao banco de dados:", error);
    throw error;
  }
};

exports.query = async (_query, values) => {
  try {
    const { rows } = await client.query(_query, values);
    return rows;
  } catch (error) {
    console.error("Database query error:", error);
    throw error;
  }
};

exports.testConnection = testConnection;
