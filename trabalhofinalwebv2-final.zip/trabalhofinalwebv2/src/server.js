const express = require("express");
const cors = require("cors");
const path = require("path"); 
const routes = require("./routes");
const app = express();

const db = require("./app/models/ConnectDatabase");
const { updateCategory } = require("./app/controllers/Category");
const { updateList } = require("./app/controllers/List");

db.testConnection().catch((err) => {      //testa conexão com bd
    console.error(
        "Não foi possível conectar ao banco de dados. Encerrando o aplicativo."
    );
    process.exit(1);
});

app.use(express.json());
app.use(routes);
app.use(cors());

app.use(express.static("front"));     //servindo arquivos da pasta front


app.get("/", (request, response) => { //rota para pg inicial
    response
        .status(200)
        .sendFile(path.join(__dirname + "/../front/index.html"));
});

app.post('/api/data', (req, res) => {
    // Aqui você pode acessar o corpo da requisição
    const data = req.body;
    console.log(data); // Mostra os dados recebidos no console
    res.status(200).json({ message: 'Dados recebidos com sucesso', data });
});

app.put('/api/data/:id', (req, res) => {
    // Extrair o ID da URL e os dados do corpo da requisição
    const taskId = req.params.id;
    const updatedData = req.body;  // Os dados que serão atualizados (no corpo da requisição)
    res.status(200).json({ message: 'Dados recebidos com sucesso', data });
});


app.delete('/api/data/:id', (req, res) => {
    // Aqui você pode acessar o corpo da requisição
    const data = req.params;
    console.log(data); // Mostra os dados recebidos no console
    res.status(200).json({ message: 'Dados recebidos com sucesso', data });
});


app.listen(8000, () => {
    console.log("O servidor está rodando em localhost:8000");
});