document.getElementById("task").addEventListener("submit", async function (event) {
  event.preventDefault();

  const formData = {
    id: Date.now(),
    titulo: document.getElementById("titulo").value,
    categoria: document.getElementById("categoria").value,
    data: document.getElementById("data").value,
    hora: document.getElementById("hora").value,
    descricao: document.getElementById("descricao").value,
  };

  console.log("Enviando dados para o servidor:", formData);

  try {
    // Enviar dados para o servidor (POST)
    const response = await fetch("http://localhost:8000/api/data", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });

    const data = await response.json();
    if (response.ok) {
      console.log("Tarefa salva com sucesso!", data);
      formData.id = data.id; // Usar ID retornado pelo servidor

      // Criar item na lista
      const li = document.createElement("li");
      li.id = `task-${formData.id}`;
      li.textContent = `${formData.titulo} - ${formData.data} ${formData.hora} (${formData.categoria}): ${formData.descricao}`;

      // Botões de editar e deletar
      li.appendChild(createEditButton(formData, li));
      li.appendChild(createDeleteButton(formData.id, li));

      document.querySelector("#taskul").appendChild(li);
      document.getElementById("task").reset();
    } else {
      console.error("Erro ao salvar a tarefa:", data);
    }
  } catch (error) {
    console.error("Erro ao salvar a tarefa:", error);
  }
});

// Função para editar uma tarefa
async function editarTarefa(formData, listItem) {
  const updatedFormData = {
    ...formData,
    titulo: prompt("Atualizar título:", formData.titulo) || formData.titulo,
    categoria: prompt("Atualizar categoria:", formData.categoria) || formData.categoria,
    data: prompt("Atualizar data:", formData.data) || formData.data,
    hora: prompt("Atualizar hora:", formData.hora) || formData.hora,
    descricao: prompt("Atualizar descrição:", formData.descricao) || formData.descricao,
  };

  try {
    const response = await fetch(`http://localhost:8000/api/data/${formData.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updatedFormData),
    });

    const data = await response.json();
    if (response.ok) {
      console.log("Tarefa atualizada com sucesso!", data);

      // Atualizar item da lista
      listItem.textContent = `${updatedFormData.titulo} - ${updatedFormData.data} ${updatedFormData.hora} (${updatedFormData.categoria}): ${updatedFormData.descricao}`;

      // Reanexar botões
      listItem.appendChild(createEditButton(updatedFormData, listItem));
      listItem.appendChild(createDeleteButton(updatedFormData.id, listItem));
    } else {
      console.error("Erro ao atualizar a tarefa:", data);
    }
  } catch (error) {
    console.error("Erro ao atualizar a tarefa:", error);
  }
}

// Função para deletar uma tarefa
async function deletarTarefa(id, listItem) {
  try {
    const response = await fetch(`http://localhost:8000/api/data/${id}`, {
      method: "DELETE",
    });

    if (response.ok) {
      console.log("Tarefa deletada com sucesso!");
      listItem.remove(); // Remover item da lista
    } else {
      console.error("Erro ao deletar a tarefa.");
    }
  } catch (error) {
    console.error("Erro ao deletar a tarefa:", error);
  }
}

// Funções auxiliares para criar botões
function createEditButton(formData, listItem) {
  const editButton = document.createElement("button");
  editButton.textContent = "Editar";
  editButton.onclick = function () {
    editarTarefa(formData, listItem);
  };
  return editButton;
}

function createDeleteButton(id, listItem) {
  const deleteButton = document.createElement("button");
  deleteButton.textContent = "Deletar";
  deleteButton.onclick = function () {
    deletarTarefa(id, listItem);
  };
  return deleteButton;
}
